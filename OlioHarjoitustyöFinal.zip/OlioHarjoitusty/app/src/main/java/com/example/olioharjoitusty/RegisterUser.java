package com.example.olioharjoitusty;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterUser extends AppCompatActivity {

    TextView registerBanner, registerButton;
    EditText registerEmailAddress, registerPassword1, registerPassword2;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        mAuth = FirebaseAuth.getInstance();

        registerBanner = (TextView) findViewById(R.id.registerBanner);

        registerEmailAddress = (EditText) findViewById(R.id.registerEmailAddress);
        registerPassword1 = (EditText) findViewById(R.id.registerPassword1);
        registerPassword2 = (EditText) findViewById(R.id.registerPassword2);

        registerButton = (Button) findViewById(R.id.registerButton);
        // this method assures that inputs are valid before registering new user to Firebase
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail = registerEmailAddress.getText().toString();
                String pwd = registerPassword1.getText().toString();
                String pwd2 = registerPassword2.getText().toString();

                // checking email and passwords
                if (mail.isEmpty()) {
                    registerEmailAddress.setError("E-mail is required!");
                    registerEmailAddress.requestFocus();
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
                    registerEmailAddress.setError("Provide a valid email address!");
                    registerEmailAddress.requestFocus();
                    return;
                } else if (pwd.isEmpty()) {
                    registerPassword1.setError("Password is required!");
                    registerPassword1.requestFocus();
                    return;
                } else if (mail.isEmpty() && pwd.isEmpty()) {
                    Toast.makeText(RegisterUser.this, "E-mail and password required!", Toast.LENGTH_SHORT).show();
                } else if (!(pwd.equals(pwd2))) {
                    Toast.makeText(RegisterUser.this, "Passwords don't match!", Toast.LENGTH_SHORT).show();
                }
                else if (pwd.equals(pwd2)) {
                    boolean test;
                    // method ensuring that password meets requirements
                    test = checkPwd(pwd);
                    if (!test) {
                        registerPassword1.setError("Password min 8 chars, contain uppercase letters, special characters and numbers");
                    }
                }

                // finally create user to Firebase if task is successful
                if (!(mail.isEmpty() && pwd.isEmpty()) && pwd.equals(pwd2) && checkPwd(pwd)) {
                    mAuth.createUserWithEmailAndPassword(mail, pwd).addOnCompleteListener(RegisterUser.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(RegisterUser.this, "Registration successful!", Toast.LENGTH_LONG).show();
                                // go to MainActivity to use the app
                                startActivity(new Intent(RegisterUser.this, MainActivity.class));
                            } else {
                                // if task not successful, print error
                                Toast.makeText(RegisterUser.this, "Sign up failed", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        });

        // if user presses the "Finnkino" banner, app directs user back to LoginActivity
        registerBanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goBack = new Intent(RegisterUser.this, LoginActivity.class);
                startActivity(goBack);
            }
        });
    }

    // password requirements
    public boolean checkPwd(String password) {
        boolean valid = false;
        boolean length = false;
        boolean number = false;
        boolean special = false;
        boolean upper = false;

        if (password.length() >= 8) {
            length = true;
        }
        if (password.contains(" ")) {
            valid = false;
        }
        char[] passwordArr = password.toCharArray();
        for (char c: passwordArr) {
            if (Character.isDigit(c)) {
                number = true;
            }
            if (Character.isUpperCase(c)) {
                upper = true;
            }
        }
        Pattern pattern = Pattern.compile("[^a-z0-9]", Pattern.CASE_INSENSITIVE);
        Matcher match = pattern.matcher(password);
        if (match.find()) {
            special = true;
        }
        if (length && number && special && upper) {
            valid = true;
        }
        return valid;
    }
}