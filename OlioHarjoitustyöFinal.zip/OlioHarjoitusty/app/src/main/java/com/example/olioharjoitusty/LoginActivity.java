package com.example.olioharjoitusty;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.w3c.dom.Text;

public class LoginActivity extends AppCompatActivity {

    TextView register, loginBanner;
    EditText loginEmailAddress, loginPassword;
    Button loginButton;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        register = (TextView) findViewById(R.id.register);
        register.setTypeface(null, Typeface.BOLD_ITALIC);

        loginButton = (Button) findViewById(R.id.loginButton);
        loginEmailAddress = (EditText) findViewById(R.id.loginEmailAddress);
        loginPassword = (EditText) findViewById(R.id.loginPassword);

        mAuth = FirebaseAuth.getInstance();

        // login if user already exists in Firebase
        loginButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                String email = loginEmailAddress.getText().toString();
                String password = loginPassword.getText().toString();
                // checking that inputs are valid
                if (email.isEmpty()) {
                    loginEmailAddress.setError("E-mail required!");
                    loginEmailAddress.requestFocus();
                    return;
                }

                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    loginEmailAddress.setError("Enter a valid e-mail!");
                    loginEmailAddress.requestFocus();
                    return;
                }

                if (password.isEmpty()) {
                    loginPassword.setError("Password required!");
                    loginPassword.requestFocus();
                    return;
                }

                // sign user in to Firebase if task successful
                if (!password.isEmpty() && !email.isEmpty()) {
                    mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if(task.isSuccessful()) {
                                // go to MainActivity and start app
                                Intent startApp = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(startApp);
                            }
                            else {
                                // inform user that login failed if signing in to Firebase failed
                                Toast.makeText(LoginActivity.this, "Login failed.", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        });

        // take user to RegisterUser activity if they want to register
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newUser = new Intent(LoginActivity.this, RegisterUser.class);
                startActivity(newUser);
            }
        });
    }

}