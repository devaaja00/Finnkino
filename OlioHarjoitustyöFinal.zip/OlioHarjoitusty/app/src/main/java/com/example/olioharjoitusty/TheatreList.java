package com.example.olioharjoitusty;

import java.util.ArrayList;

public class TheatreList {
    public String id;
    public String name;
    ArrayList<String > movieList = new ArrayList<>();
    public TheatreList(String name, String id){
        this.name = name;
        this.id = id;
    }

    @Override
    public String toString() {
        return name;
    }
}
