package com.example.olioharjoitusty;

public class UserInfo {

    public String email;

    public UserInfo() {
    }

    public UserInfo(String email) {
        this.email = email;
    }
}
